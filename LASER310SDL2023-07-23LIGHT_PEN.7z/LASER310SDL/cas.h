#ifndef CAS_H_
#define CAS_H_

void cas_set_data(uint8_t* cas_name, uint8_t cas_type, uint16_t cas_start, uint16_t cas_len, uint8_t *cas_dat);
int cas_read(uint64_t ticks);

#endif	// CAS_H_
