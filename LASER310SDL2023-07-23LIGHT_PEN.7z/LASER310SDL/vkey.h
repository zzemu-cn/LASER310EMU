#ifndef VKEY_H_
#define VKEY_H_

typedef struct {
	int		i;
	int		j;
	int		shift;
} vkeymap;

extern vkeymap vkey[256];

#endif	//VKEY_H_

