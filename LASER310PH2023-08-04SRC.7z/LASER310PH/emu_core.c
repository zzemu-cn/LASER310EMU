#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include <SDL2/SDL.h>

#include "stb/bithacks.h"

//#define ENABLE_DBG
//#include "stb/dbg.h"
//#define ENABLE_LOG
#include "stb/log.h"

#include "emu_core.h"
#include "cas.h"

extern uint64_t ticks;
extern uint64_t cas_ticks;

extern unsigned int cycles_count;

void playSound();

uint8_t emu_fetch_byte(void *context, uint16_t adr)
{
	uint8_t x = emu_read_byte(context, adr);
/*
	DBG("fetch %04X %02X", adr, x);
	DBG("status %d  PC %04X  BC %04X  DE %04X  HL %04X  AF %04X\n", vzcontext.state.status, vzcontext.state.pc,
		vzcontext.state.registers.word[Z80_BC], vzcontext.state.registers.word[Z80_DE], vzcontext.state.registers.word[Z80_HL], vzcontext.state.registers.word[Z80_AF]
	);
*/
	return x;
}

uint16_t emu_fetch_word(void *context, uint16_t adr)
{
	uint16_t h, l;
	l = emu_fetch_byte(context, adr);
	h = emu_fetch_byte(context, adr+1);
	return (h<<8)|l;
}

const uint8_t uint8_b0 = 1;
const uint8_t uint8_b1 = 2;
const uint8_t uint8_b2 = 4;
const uint8_t uint8_b3 = 8;
const uint8_t uint8_b4 = 16;
const uint8_t uint8_b5 = 32;
const uint8_t uint8_b6 = 64;
const uint8_t uint8_b7 = 128;

const uint16_t uint16_b0 = 1;
const uint16_t uint16_b1 = 2;
const uint16_t uint16_b2 = 4;
const uint16_t uint16_b3 = 8;
const uint16_t uint16_b4 = 16;
const uint16_t uint16_b5 = 32;
const uint16_t uint16_b6 = 64;
const uint16_t uint16_b7 = 128;

/*
   KD5 KD4 KD3 KD2 KD1 KD0 扫描用地址
A0  R   Q   E       W   T  68FEH       0
A1  F   A   D  CTRL S   G  68FDH       8
A2  V   Z   C  SHFT X   B  68FBH      16
A3  4   1   3       2   5  68F7H      24
A4  M  空格 ，      .   N  68EFH      32
A5  7   0   8   -   9   6  68DFH      40
A6  U   P   I  RETN O   Y  68BFH      48
A7  J   ；  K   :   L   H  687FH      56
*/

// KD6 录音机输入

uint8_t emu_read_byte(void *context, uint16_t adr)
{
	uint8_t x = 0xff;
	uint16_t mask = 0x0001;
	uint8_t ch;

	x = ((VZCONTEXT *)context)->memory[adr&0xffff];

	if((adr&0xf800)==0x6800) {
		//D5~D0用于读键盘信息
		x = 0x00;

		//MC6847：KD7连接IC15第37脚（垂直同步信号/FS，即CPU的/INT请求信号，在场扫描期间为1，场消隐期间为0）

		// 垂直回扫 MC4847	/FS
		if(cycles_count<70980*32/312)
			B_SET(x,7);	// 这里是正向，函数最后有一句 x = ~x


		for(int i=0;i<8;i++) {
			if(!(adr&mask)) {
				x |= ((VZCONTEXT *)context)->scancode[i];
				x |= ((VZCONTEXT *)context)->vscancode[i];
			}
			mask <<=1;
		}

		// 扩展按键  scancode[8] 上下左右 Backspace TAB ESC `  scancode[9] = [ ] \ / LALT RALT
		ch = ((VZCONTEXT *)context)->scancode[8];
		// ESC    CTRL + -
		if(B_IS_SET(ch, 6)) {
			if(!(adr&uint16_b1))	B_SET(x,2);	// ctrl
			if(!(adr&uint16_b5))	B_SET(x,2);	// -
		}
		// 退格键 CTRL + M
		if(B_IS_SET(ch, 4)) {
			if(!(adr&uint16_b1))	B_SET(x,2);	// ctrl
			if(!(adr&uint16_b4))	B_SET(x,5);	// m
		}

		// KD6 录音机输入
		if(cas_ticks) {
			if(cas_read(ticks-cas_ticks)) x|=0x40;
		}

		x = ~x;
	}

	// 0x4000 --- 0x5fff 扩充VRAM
	if((adr&0xe000)==0x4000) {
		//Q1==0 DOS区域 Q1==1 VRAM 区域
		if(((VZCONTEXT *)context)->latched_ga && 0x02)
			x = ((VZCONTEXT *)context)->vram[(adr&0x1fff)];
	}

	// 0x7000 --- 0x77ff 原系统VRAM空间
	if((adr&0xf800)==0x7000) {
		x = ((VZCONTEXT *)context)->vram[(adr&0x07ff)];

		//LOG("BR %04X %02X\n", adr, x);
	}

	//if((adr&0xff00)==0xff00) x = 0xff;
	//LOG("BR %04X %02X", adr, x);

	return x;
}

uint16_t emu_read_word(void *context, uint16_t adr)
{
	uint16_t h, l;
	l = emu_read_byte(context, adr);
	h = emu_read_byte(context, adr+1);
	return (h<<8)|l;
}

// 扩充 Q1==0 DOS区域 Q1==1 VRAM 区域。
// 扩充 Q7、Q6控制GM2和GM0
// Q5和Q0同置为1，启动磁带机
uint8_t emu_write_byte(void *context, uint16_t adr, uint8_t x)
{
	uint8_t last_x, cur_x;
	if((adr&0xf800)==0x6800) {
		// D5，D0 扬声器 00 11 都是无声 10 01 不同则发声
		last_x = ((VZCONTEXT *)context)->latched_ga&0x21;
		cur_x = x&0x21;
		if((cur_x==0x20||cur_x==0x01) && last_x!=cur_x)
			playSound();

		//if(cur_x==0x21) // 开启磁带机
		((VZCONTEXT *)context)->latched_ga = x;
	}

	// 0x4000 --- 0x5fff 扩充VRAM
	if((adr&0xe000)==0x4000) {
		//Q1==0 DOS区域 Q1==1 VRAM 区域
		if(((VZCONTEXT *)context)->latched_ga && 0x02)
			((VZCONTEXT *)context)->vram[(adr&0x1fff)] = x;

		if((adr<0x4000+32*16) && (x!=0))
			LOG("BWH %04X %02X %04X\n", adr, x, ((VZCONTEXT *)context)->state.pc);
	}

	// 0x7000 --- 0x77ff 原系统VRAM空间
	if((adr&0xf800)==0x7000) {
		((VZCONTEXT *)context)->vram[(adr&0x07ff)] = x;

		if((adr<0x7000+32*16) && (x!=0))
			LOG("BW %04X %02X %04X\n", adr, x, ((VZCONTEXT *)context)->state.pc);
		//LOG("BW %04X %02X\n", adr, x);
	}

	// RAM空间
	//if(adr>=0x7800) {	// 34KB
	if(adr>=0x7800 && adr<=0xB7FF) {	// 16KB
		((VZCONTEXT *)context)->memory[adr&0xffff] = x;
	}

	//LOG("BW %04X %02X", adr, x);

	return x;
}

uint16_t emu_write_word(void *context, uint16_t adr, uint16_t x)
{
	emu_write_byte(context, adr, x&0xff);
	emu_write_byte(context, adr+1, (x>>8)&0xff);

	return x;
}


uint8_t emu_sysio_input(void *context, uint8_t port)
{
	uint8_t x = 0xff;
	uint8_t ch;

	// joystick
	if((port&0xF0)==0x20) {
		// joystick 1
		if(!(port&0x01)) {
			// 键盘模拟游戏杆输入 上下左右 tab `
			ch = ((VZCONTEXT *)context)->scancode[8];
			if(ch&0x01) B_UNSET(x,0);
			if(ch&0x02) B_UNSET(x,1);
			if(ch&0x04) B_UNSET(x,2);
			if(ch&0x08) B_UNSET(x,3);
			if(ch&0x20) B_UNSET(x,4);	// tab
		}
		if(!(port&0x02)) {
			// 键盘模拟游戏杆输入
			ch = ((VZCONTEXT *)context)->scancode[8];
			if(ch&0x80) B_UNSET(x,4);	// `
		}
/*	
		// joystick 2
		if(!(port&0x04)) {
			// 键盘模拟游戏杆输入  上下左右 tab `
			ch = ((VZCONTEXT *)context)->scancode[8];
			if(ch&0x01) B_UNSET(x,0);
			if(ch&0x02) B_UNSET(x,1);
			if(ch&0x04) B_UNSET(x,2);
			if(ch&0x08) B_UNSET(x,3);
			if(ch&0x20) B_UNSET(x,4);	// tab
		}
		if(!(port&0x08)) {
			// 键盘模拟游戏杆输入
			ch = ((VZCONTEXT *)context)->scancode[8];
			if(ch&0x80) B_UNSET(x,4);	// `
		}
*/
	}

/*
	//if(port==ADDRESS_IO_FDC_CT||port==ADDRESS_IO_FDC_DATA||port==ADDRESS_IO_FDC_POLL||port==ADDRESS_IO_FDC_WP)
	if(port==ADDRESS_IO_FDC_WP)
		x = 0;
		//x = 0x80;

	if(port==ADDRESS_IO_FDC_POLL) {
		x = fdc_io_poll();
		//int c = fdc_io_cycles();
		//uint16_t pc = ((VZCONTEXT *)context)->state.pc;
		//if(pc==0x5663 || pc==0x5675 || pc==0x5685)
		//	LOG("adr %04X: FDC_POLL %02X, %02X (%d : %s %02x %02x %d)",((VZCONTEXT *)context)->state.pc,port,x, fd_pos, fd_date_d1(), fd_poll_dat_d1, fdc_dat_latch, c);
	}

	// IDAM 0xFE, 0xE7, 0x18, 0xC3
	if(port==ADDRESS_IO_FDC_DATA) {
		x = fdc_io_data();
		//int c = fdc_io_cycles();
		//uint16_t pc = ((VZCONTEXT *)context)->state.pc;
		//if(pc==0x5542&&x==0xFE || pc==0x55C7&&x==0xE7 || pc==0x564C&&x==0x18 || pc==0x5673 || pc==0x5683 || pc==0x56D1 || pc==0x5746)
		//if(pc==0x5673 || pc==0x5683 || pc==0x56D1 || pc==0x5746)
		//	LOG("adr %04X: FDC_DATA %02X, %02X (%d : %s %02x %02x %d)",((VZCONTEXT *)context)->state.pc,port,x, fd_pos, fd_date_d1(), fd_poll_dat_d1, fdc_dat_latch, c);

		//if(pc==0x57E6 || pc==0x5873) {	// IDAM
		//	fd_idam_sec = ((VZCONTEXT *)context)->state.registers.byte[Z80_D];
		//	LOG("adr %04X: FDC_DATA %02X, %02X (%d : S%02X)",((VZCONTEXT *)context)->state.pc,port,x, fd_pos, fd_idam_sec);
		//}


		// 引入读盘偏差
//		if(pc==0x57E6) {
//			fd_pos += rand()%5;
//			if(fd_pos>=FD_TRACK_LEN) fd_pos -= FD_TRACK_LEN;
//		}
	}
*/

	return x;
}

uint8_t emu_sysio_output(void *context, uint8_t port, uint8_t x)
{
	//DBG("out %d, %02x", port, x);

/*
	if(port==32||port==222)
		vzcontext.latched_shrg = x;
*/

/*
	if(port==ADDRESS_IO_FDC_CT)
		fdc_io_ct(x);
*/

	return x;
}

