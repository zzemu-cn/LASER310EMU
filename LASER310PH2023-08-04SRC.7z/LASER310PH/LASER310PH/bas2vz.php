<?php
// CEC-I 汉字库
$cclib = file_get_contents("FONT/U33.MX231024-0059.bin").file_get_contents("FONT/U34.MX231024-0060.bin");

$zhlib = [];

# LASER-310 ROM 1650

/*
【PH扩充保留词所含代号表】
B2E9- B2	;HPRINT(B2)
B2EA- C6	;HPOINT(C6)
B2EB- D2	;RANDOM(D2)
B2EC- D8	;CINT(D8)
*/

/*
$vzkey = [
	"END",		"FOR",		"RESET",	"SET",		"CLS",		"",			"~RANDOM",	"NEXT",		// 0x80
	"DATA",		"INPUT",	"DIM",		"READ",		"LET",		"GOTO",		"RUN",		"IF",		// 0x88
	"RESTORE",	"GOSUB",	"RETURN",	"REM",		"STOP",		"ELSE",		"COPY",		"COLOR",	// 0x90
	"VERIFY",	"~DEFINT",	"~DEFSNG",	"~DEFDBL",	"CRUN",		"MODE",		"SOUND",	"RESUME",	// 0x98
	"OUT",		"~ON",		"",			"",			"",			"",			"",			"",			// 0xA0
	"",			"",			"",			"",			"",			"",			"~SYSTEM",	"LPRINT",	// 0xA8
	"",			"POKE",		"PRINT",	"CONT",		"LIST",		"LLIST",	"~DELETE",	"~AUTO",	// 0xB0
	"CLEAR",	"CLOAD",	"CSAVE",	"NEW",		"TAB(",		"TO",		"",			"USING",	// 0xB8
	"~VARPTR",	"USR",		"~ERL",		"~ERR",		"~STRING$",	"",			"POINT",	"",			// 0xC0
	"~MEM",		"INKEY$",	"THEN",		"NOT",		"STEP",		"+",		"-",		"*",		// 0xC8
	"/",		"^",		"AND",		"OR",		">",		"=",		"<",		"SGN",		// 0xD0
	"INT",		"ABS",		"~FRE",		"INP",		"~POS",		"SQR",		"RND",		"LOG",		// 0xD8
	"EXP",		"COS",		"SIN",		"TAN",		"ATN",		"PEEK",		"",			"",			// 0xE0
	"",			"",			"",			"",			"",			"",			"",			"~CINT",	// 0xE8
	"~CSNG",	"~CDBL",	"~FIX",		"LEN",		"STR$",		"VAL",		"ASC",		"CHR$",		// 0xF0
	"LEFT$",	"RIGHT$",	"MID$",		"",			"",			"",			"",			"",			// 0xF8
];
*/

$vzkey = [
	"END",		"FOR",		"RESET",	"SET",		"CLS",		"",			"RANDOM",	"NEXT",		// 0x80
	"DATA",		"INPUT",	"DIM",		"READ",		"LET",		"GOTO",		"RUN",		"IF",		// 0x88
	"RESTORE",	"GOSUB",	"RETURN",	"REM",		"STOP",		"ELSE",		"COPY",		"COLOR",	// 0x90
	"VERIFY",	"DEFINT",	"DEFSNG",	"DEFDBL",	"CRUN",		"MODE",		"SOUND",	"RESUME",	// 0x98
	"OUT",		"ON",		"",			"",			"",			"",			"",			"",			// 0xA0
	"",			"",			"",			"",			"",			"",			"SYSTEM",	"LPRINT",	// 0xA8
	"",			"POKE",		"PRINT",	"CONT",		"LIST",		"LLIST",	"DELETE",	"AUTO",		// 0xB0
	"CLEAR",	"CLOAD",	"CSAVE",	"NEW",		"TAB(",		"TO",		"",			"USING",	// 0xB8
	"VARPTR",	"USR",		"ERL",		"ERR",		"STRING$",	"",			"POINT",	"",			// 0xC0
	"MEM",		"INKEY$",	"THEN",		"NOT",		"STEP",		"+",		"-",		"*",		// 0xC8
	"/",		"^",		"AND",		"OR",		">",		"=",		"<",		"SGN",		// 0xD0
	"INT",		"ABS",		"FRE",		"INP",		"POS",		"SQR",		"RND",		"LOG",		// 0xD8
	"EXP",		"COS",		"SIN",		"TAN",		"ATN",		"PEEK",		"",			"",			// 0xE0
	"",			"",			"",			"",			"",			"",			"",			"CINT",		// 0xE8
	"CSNG",		"CDBL",		"FIX",		"LEN",		"STR$",		"VAL",		"ASC",		"CHR$",		// 0xF0
	"LEFT$",	"RIGHT$",	"MID$",		"",			"",			"",			"",			"",			// 0xF8
];


function item_vals($filename)
{
	// 读取编辑的文件
	$a = array();
	if(file_exists($filename)) {
		$s = file_get_contents($filename);
		if(is_bool($s)) $s = "";

		$a = explode("\n",$s);
		if(!is_array($a)) $a = array();
	}

	return $a;
}

function word2str($n)
{
	return chr($n&0xFF).chr(($n>>8)&0xFF);
}


// GBK
// 0x81 0xFE
// 0x40 0xFE
// GB2312
// 0xA1 0xFE
// 0xA1 0xFE

function is_gb2312($s)
{
	if(strlen($s)!=2) return false;
	if($s[0]<chr(0xA1) || $s[0]==chr(0xFF)) return false;
	if($s[1]<chr(0xA1) || $s[1]==chr(0xFF)) return false;
	return true;
}

function is_gbk($s)
{
	if(strlen($s)!=2) return false;
	if($s[0]<chr(0x81) || $s[0]==chr(0xFF)) return false;
	if($s[1]<chr(0x40) || $s[1]==chr(0xFF)) return false;
	return true;
}

function zh2lib($ch)
{
	global $zhlib;

	if(!in_array($ch, $zhlib))
		array_push($zhlib,$ch);
	return array_search($ch, $zhlib);
}

//2626 汉
//((26-16)*(94) + (26-1))*16 + 44E0h = 3C50h + 44E0h = 8130h

/*
GB2312
01-09区收录除汉字外的682个字符。
10-15区为空白区，没有使用。
16-55区收录3755个一级汉字，按拼音排序。
56-87区收录3008个二级汉字，按部首/笔画排序。
88-94区为空白区，没有使用。
*/

function cclib_hz($ch)
{
	global $cclib;
	$r = "";

	$n0 = ord($ch[0])-0xA1;
	$n1 = ord($ch[1])-0xA1;

	// 空白区
	if($n0>=88-1 || $n0>=10-1 && $n0<=15-1) {
		// 汉字为空白 □ 0185
		$n0=1-1;
		$n1=85-1;
	}

	if($n0>=16-1) $n0-=6;
	$n = $n0*94+$n1;
	
	$p0 = 0x100*16+$n*16;
	$p1 = $p0 + 0x20000;
	for($i=0;$i<16;$i++) {
		$r.=$cclib[$p0+$i].$cclib[$p1+$i];
	}

	return $r;
}

// 生成汉字字库
function zhlib2bin()
{
	global $zhlib;

	$bin = "";

	foreach($zhlib as $ch) {
		$bin.=cclib_hz($ch);
	}

	return $bin;
}


function bas2bin($fn,$addr)
{
	global $vzkey;
	$bin = "";
	$lst = item_vals($fn);
	foreach($lst as $line) {
		$line = trim($line);
		if($line=="") continue;

		echo mb_convert_encoding($line, "UTF-8", "GB18030"),"\n";
		$buf="";
		$n = str_num($line);
		if($n==0) exit(0);
		$ln = intval(substr($line,0,$n));
		$buf .= word2str($ln);
		echo $ln;
		$l = strlen($line);
		$i=$n;
		$is_str=false;
		while($i<$l) {
			// 判断当前字符是否是汉字 GB2312
			$ch = $line[$i];
			$zh_ch = substr($line,$i,2);
			if(is_gb2312($zh_ch)) {
				$n = zh2lib($zh_ch);
				echo $n;
				$buf .= "$n";
				$i+=2;
				continue;
			}
			if($ch=='"') $is_str = !$is_str;
			if($is_str) {
				$n=0;
			} else {
				$n = str_keyword(substr($line,$i));
			}
			if($n>0) {
				$k=$vzkey[$n-0x80];
				$buf .= chr($n);
				printf("{%02X}%s",$n,$k);
				$i+= strlen($k);
			} else {
				$buf .= $ch;
				echo $ch;
				$i++;
			}
		}
		$buf .= "\0";
		$addr += strlen($buf)+2;
		$bin .= word2str($addr);
		$bin .= $buf;
		echo "\n";
	}

	// 程序结束标志
	$bin .= word2str(0);

	return $bin;
}

function str_num($s)
{
	//$n=strcspn($s,"0123456789");
	$n=strspn($s,"0123456789");
	return $n;
}

function str_keyword($s)
{
	global $vzkey;
	$n=0;
	foreach($vzkey as $idx=>$k) {
		if($k=="") continue;
		if(str_starts_with($s,$k)) {
			$n = $idx+0x80;
			break;
		}
	}
	return $n;
}


if($argc!=2) {
	echo "php bas2vz.php foo.bas";
	exit(1);
}

$fn_bas = $argv[1];
$fn = basename($fn_bas,".bas");

$cass_addr = 0x7AE9;
$cass_name = "";
$fn_vz = "$fn.vz";
$fn_bin = "$fn.bin";


$bin = bas2bin($fn_bas,$cass_addr);
$l = strlen($bin);
echo "BAS len $l\n";

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF0";
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$bin);
//file_put_contents($fn_bin, $bin);


# 字库放置在 AB79 之前的区域，不包括 AB79
$cass_addr = 0xAB79;
$cass_name = "ZK";
$fn_vz = "$fn.zk.vz";
$fn_bin = "$fn.zk.bin";

$bin = zhlib2bin();
$l = strlen($bin);
echo "ZK len $l\n";

if($l==0) exit(0);

$cass_addr -= $l;

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF3";	// W文件类型，用于字库
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$bin);
//file_put_contents($fn_bin, $bin);
