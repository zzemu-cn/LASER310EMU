<?php

function item_vals($filename)
{
	// 读取编辑的文件
	$a = array();
	if(file_exists($filename)) {
		$s = file_get_contents($filename);
		if(is_bool($s)) $s = "";

		$a = explode("\n",$s);
		if(!is_array($a)) $a = array();
	}

	return $a;
}

function split_char($c,$s)
{
	$v = explode($c,$s);
	$v = array_filter($v);
	return $v;
}

function split_addr($s)
{
	$v = preg_split('/[:-]/',$s);
	$v = array_filter($v);
	return $v;
}

function split_sp($s)
{
	$v = preg_split('/\s/',$s);
	$v = array_filter($v);
	return $v;
}

// 检测字符 0--9 A--F a--f
function check_hex_char($hex)
{
	//echo $hex;
	for($i=0;$i<strlen($hex);$i++) {
		$ch = $hex[$i];
		if( !( ($ch>="0"&&$ch<="9") || ($ch>="A"&&$ch<="F") || ($ch>="a"&&$ch<="f") ) )
			return false;
	}
	return true;
}


function hex_txt2str($txtfile, $start_addr, $dbg=true)
{
	$lst = item_vals($txtfile);

	$buf="";

	$addr = $start_addr;
	foreach($lst as $line) {
		//echo trim($line),"\n";
		$hex_val = '';
		// 检测地址
		$hex_lst = split_addr(trim($line));
		if(count($hex_lst)==0)
			continue;

		if(count($hex_lst)>2) {
			print_r($hex_lst);
			printf("format err : %s\n", $line);
			return "";
		}
		if(count($hex_lst)==2) {
			$hex = $hex_lst[0];
			$hex_val = $hex_lst[1];
			// 检测字符 0--9 A--F a--f
			if( !check_hex_char($hex) ) {
				echo "format err $line";
				exit(1);
			}
			if($addr!=hexdec($hex)) {
				printf("format err : %s %X\n", $hex, hexdec($hex));
				return "";
			}
		}
		if(count($hex_lst)==1) {
			$hex_val = $hex_lst[0];
		}
		if($dbg)	printf("%X :", $addr);

		$hex_lst = split_sp(trim($hex_val));
		foreach($hex_lst as $idx => $hex) {
			// 检测字符 0--9 A--F a--f
			if( !check_hex_char($hex) ) {
				echo "format err $line";
				exit(1);
			}
			if(strlen($hex)==0 || strlen($hex)%2==1) {
				printf("format err : %s\n", $hex);
				return "";
			}
			$buf .= hex2bin($hex);
			if($dbg) printf("%s", strtoupper(bin2hex(hex2bin($hex))));
			$addr+=strlen($hex)/2;
		}
		printf("\n");
	}

	return $buf;
}


// CEC-I 汉字库
$cclib = file_get_contents("FONT/U33.MX231024-0059.bin").file_get_contents("FONT/U34.MX231024-0060.bin");

// LASER-310英文字体
$fontlib_vz = file_get_contents("FONT/character set (1983)(vtech).rom");

// CEC-I 英文字体
$fontlib_cec = file_get_contents("FONT/U13.9433C-0202.RCL-ZH-32.bin");

// VGA 8x14字体可显示区域是 8x9 的点阵
$fontlib_vga = file_get_contents("FONT/ibm_vga.bin");


// PH-1

$hex_txtfile = "PH-1.hex.txt";
$cass_addr = 0x7200;
$cass_name = "PH-1";
$fn_vz = "PH-1.vz";
$fn_bin = "PH-1.7200.bin";

$buf = hex_txt2str($hex_txtfile, $cass_addr);
if(!$buf) {
	printf("buf err %s\n",$hex_txtfile);
	exit(0);
}

//printf("start addr %02X %02X", $cass_addr&0xFF, ($cass_addr>>8)&0xFF);
printf("out file name  %s\n", $fn_vz);
printf("start addr %X\n", $cass_addr);
printf("bin len %X (%d)\n", strlen($buf), strlen($buf));

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF2";
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$buf);

file_put_contents($fn_bin, $buf);


	
printf("\n\n");


// PH-2

$hex_txtfile = "PH-2.hex.txt";
$cass_addr = 0x785D;
$cass_name = "PH-2";
$fn_vz = "PH-2.vz";
$fn_bin = "PH-2.785D.bin";

$buf = hex_txt2str($hex_txtfile, $cass_addr);
if(!$buf) {
	printf("buf err %s\n",$hex_txtfile);
	exit(0);
}

//printf("start addr %02X %02X", $cass_addr&0xFF, ($cass_addr>>8)&0xFF);
printf("out file name  %s\n", $fn_vz);
printf("start addr %X\n", $cass_addr);
printf("bin len %X (%d)\n", strlen($buf), strlen($buf));

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF2";
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$buf);

file_put_contents($fn_bin, $buf);


	
printf("\n\n");

// PH-3

$hex_txtfile = "PH-3.hex.txt";
$cass_addr = 0x7952;
$cass_name = "PH-3";
$fn_vz = "PH-3.vz";
$fn_bin = "PH-3.7952.bin";

$buf = hex_txt2str($hex_txtfile, $cass_addr);
if(!$buf) {
	printf("buf err %s\n",$hex_txtfile);
	exit(0);
}

//printf("start addr %02X %02X", $cass_addr&0xFF, ($cass_addr>>8)&0xFF);
printf("out file name  %s\n", $fn_vz);
printf("start addr %X\n", $cass_addr);
printf("bin len %X (%d)\n", strlen($buf), strlen($buf));

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF2";
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$buf);

file_put_contents($fn_bin, $buf);


	
printf("\n\n");

// PH-4 扩充代号相对地址表及ASCII字库
// 5C7AH～ 5C9FH
// ASCII字符点阵数据首址=字库首址+(ASCII码-20H)×09H。
// 长度0x0360 = 864 = 9*96  8×9的ASCII点阵字库
// VGA 8x14字体可显示区域是 8x9 的点阵
// ASCII字库点阵从 5CA0H 开始

$hex_txtfile = "PH-4.hex.txt";
$cass_addr = 0x5C7A;
$cass_name = "PH-4";
$fn_vz = "PH-4.vz";
$fn_bin = "PH-4.5C7A.bin";

$buf_1 = hex_txt2str($hex_txtfile, $cass_addr);
if(!$buf) {
	printf("buf err %s\n",$hex_txtfile);
	exit(0);
}

function byte_rev($n)
{
	$r=0;
	$b=0x80;
	for($i=0;$i<8;$i++) {
		if($n&1) $r+=$b;
		$b = $b>>1;
		$n = $n>>1;
	}
	return $r;
}

function font_vz($n)
{
	global $fontlib_vz;
	$r = "";
	$p = $n*12;
	for($i=0;$i<9;$i++) {
		$ch = $fontlib_vz[$p+$i];
		// 反转
		$ch = chr(byte_rev(ord($ch)));
		$r.=$ch;
	}

	return $r;
}

function font_cec($n)
{
	global $fontlib_cec;
	$r = "";
	$p = $n*8;
	for($i=0;$i<8;$i++) {
		$ch = $fontlib_cec[$p+$i];
		// 反转
		$ch = chr(byte_rev(ord($ch)));
		$r.=$ch;
	}
	$r.=chr(0);

	return $r;
}

function font_vga14($n)
{
	global $fontlib_vga;
	$r = "";
	//$p = $n*12;
	// 0x05F8D 每个字符占14个字节
	$p = $n*14+0x05F8D;
	//for($i=0;$i<9;$i++) {
	for($i=0+2;$i<9+2;$i++) {
		$ch = $fontlib_vga[$p+$i];
		// 反转
		//$ch = chr(byte_rev(ord($ch)));
		$r.=$ch;
	}

	return $r;
}

function fontlib_ph()
{
	$r = "";
	// 0x20 -- 0x3F
	for($n=0x20;$n<0x40;$n++)
		$r .= font_vz($n);

	//for($n=0x20;$n<0x40;$n++)
	//	$r .= font_cec($n);

	// 0x40 -- 0x5F
	for($n=0x0;$n<0x20;$n++)
		$r .= font_vz($n);

	//for($n=0x0;$n<0x20;$n++)
	//	$r .= font_cec($n);

	// 0x60 -- 0x7F
	//for($n=0x60;$n<0x80;$n++)
	//	$r .= font_vga14($n);

	for($n=0x60;$n<0x80;$n++)
		$r .= font_cec($n);

	return $r;
}

#$buf_2 = substr($cclib, 0x0200, 0x0360);
$buf_2 = fontlib_ph();

$buf = $buf_1.$buf_2;

//printf("start addr %02X %02X", $cass_addr&0xFF, ($cass_addr>>8)&0xFF);
printf("out file name  %s\n", $fn_vz);
printf("start addr %X\n", $cass_addr);
printf("bin len %X (%d)\n", strlen($buf), strlen($buf));

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF2";
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$buf);

file_put_contents($fn_bin, $buf);


	
printf("\n\n");

// PH-5 主模块

$hex_txtfile = "PH-5.hex.txt";
$hex_txtfile1 = "PH-5.1.hex.txt";
$hex_txtfile2 = "PH-5.2.hex.txt";
$hex_txtfile3 = "PH-5.3.hex.txt";

$cass_addr = 0xAB59;
$cass_addr1 = 0xAB59;
$cass_addr2 = 0xAB79;
$cass_addr3 = 0xACB9;

$cass_name = "PH-5";
$fn_vz = "PH-5.vz";
$fn_bin = "PH-5.AB59.bin";

//2626 汉
//((26-16)*(94) + (26-1))*16 + 44E0h = 3C50h + 44E0h = 8130h

function cclib_hz($n)
{
	global $cclib;
	$r = "";
	$p0 = $n*16 + 0x44E0;
	$p1 = $p0 + 0x20000;
	for($i=0;$i<16;$i++) {
		$r.=$cclib[$p0+$i].$cclib[$p1+$i];
	}

	return $r;
}

// AB59 -- AB78
$han_off = 0x8130;
//$buf_1 = substr($cclib, $han_off, 16).substr($cclib, $han_off+0x20000, 16);
$buf_1 = cclib_hz((26-16)*(94) + (26-1));

// AB79
$buf_2 = hex_txt2str($hex_txtfile2, $cass_addr2);
if(!$buf) {
	printf("buf err %s\n",$hex_txtfile2);
	exit(0);
}

printf("PH-5.2 bin len %X (%d)\n", strlen($buf_2), strlen($buf_2));

// ACB9
$buf_3 = hex_txt2str($hex_txtfile3, $cass_addr3);
if(!$buf) {
	printf("buf err %s\n",$hex_txtfile3);
	exit(0);
}

$buf = $buf_1.$buf_2.$buf_3;

//printf("start addr %02X %02X", $cass_addr&0xFF, ($cass_addr>>8)&0xFF);
printf("out file name  %s\n", $fn_vz);
printf("start addr %X\n", $cass_addr);
printf("bin len %X (%d)\n", strlen($buf), strlen($buf));

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF2";
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$buf);

file_put_contents($fn_bin, $buf);


	
printf("\n\n");


// PH1.3

$hex_txtfile = "PH1.3.hex.txt";
$cass_addr = 0x7AE9;
$cass_name = "PH1.3";
$fn_vz = "PH1.3.vz";
$fn_bin = "PH1.3.7AE9.bin";

$buf = hex_txt2str($hex_txtfile, $cass_addr);
if(!$buf) {
	printf("buf err %s\n",$hex_txtfile);
	exit(0);
}

//printf("start addr %02X %02X", $cass_addr&0xFF, ($cass_addr>>8)&0xFF);
printf("out file name  %s\n", $fn_vz);
printf("start addr %X\n", $cass_addr);
printf("bin len %X (%d)\n", strlen($buf), strlen($buf));

$vz_magic = "VZF0";
$vz_filename = $cass_name;
while(strlen($vz_filename)<17) {
	$vz_filename .= "\0";
}
$vz_type = "\xF1";
$vz_startaddr = chr($cass_addr&0xFF) . chr(($cass_addr>>8)&0xFF);

file_put_contents($fn_vz, $vz_magic.$vz_filename.$vz_type.$vz_startaddr.$buf);

file_put_contents($fn_bin, $buf);


// C/E
// CREATE/EDIT

//$hex_txtfile1 = "CE-BAS.txt";
$hex_txtfile2 = "CE-BIN.hex.txt";
$cass_addr = 0x7AE9;
$cass_addr1 = 0x7AE9;
$cass_addr2 = 0x7FE0;

$cass_name = "C/E";
$fn_vz = "CE.vz";
$fn_bin = "CE.7AE9.bin";

$buf_2 = hex_txt2str($hex_txtfile2, $cass_addr2);
if(!$buf_2) {
	printf("buf err %s\n",$hex_txtfile2);
	exit(0);
}
