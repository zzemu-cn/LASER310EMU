#include "prgdef.h"

uint8_t tmp_buf[TMP_BUF_LEN];

//wchar_t	exe_path[1024];				/* path (dir) of executable */
//wchar_t	usr_path[1024];				/* path (dir) of user data */
//wchar_t	cfg_path[1024];				/* full path of config file */

