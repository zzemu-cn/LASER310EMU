//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//

#define IDR_MENU1                       		101

#define IDM_FILE_OPEN_VZ                        40001
#define IDM_FILE_OPEN_DSK1                      40002
#define IDM_FILE_OPEN_DSK2                      40003
#define IDM_FILE_EXIT                           40004
#define IDM_EMULATE_RUN                         40005
#define IDM_EMULATE_PAUSE                       40006
#define IDM_EMULATE_RESET                       40007
#define IDM_OPTIONS_DISPLAYSIZE_1X              40008
#define IDM_OPTIONS_DISPLAYSIZE_2X              40009
#define IDM_OPTIONS_DISPLAYSIZE_3X              40010
#define IDM_OPTIONS_DISPLAYSIZE_FULLSCREEN      40011
#define IDM_ACTION_SCREENSHOT                   40012


/* For the DeviceConfig code, re-do later. */
/*
#define IDC_HDTYPE      1380
#define IDC_RENDER      1381
#define IDC_STATUS      1382
*/

// Next default values for new objects
//
/*
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1001
#define _APS_NEXT_COMMAND_VALUE         1002
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           1004
#endif
#endif
*/
